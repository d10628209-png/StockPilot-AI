# StockPilot AI

Gradio-based inventory dashboard for Render.

Install dependencies with `pip install -r requirements.txt` and run `python app.py`.

The demonstration dataset is simulated. Demand forecasts use Random Forest models trained at startup.
