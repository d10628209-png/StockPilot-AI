# StockPilot AI — Render deployment
# Data is simulated for demonstration; Random Forest forecasts are trained at startup.

import random
import gradio as gr
import pandas as pd
import numpy as np
import plotly.express as px

# Notebook display calls are disabled in the hosted web app.
def display(*args, **kwargs):
    return None
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

SHOP_NAME = "StockPilot AI"
SHOP_TYPE = "General Retail Store"
FORECAST_PERIODS = [7, 30, 90]
CURRENCY = "₹"

random.seed(42)
np.random.seed(42)


import random

random.seed(42)
np.random.seed(42)

products = [
    ("P001", "Rice 5kg", "Groceries", 85, 280, 350),
    ("P002", "Wheat Flour 5kg", "Groceries", 60, 180, 230),
    ("P003", "Sugar 1kg", "Groceries", 90, 38, 48),
    ("P004", "Cooking Oil 1L", "Groceries", 45, 110, 140),
    ("P005", "Salt 1kg", "Groceries", 100, 18, 25),
    ("P006", "Tea Powder 500g", "Beverages", 35, 140, 180),
    ("P007", "Coffee 200g", "Beverages", 40, 120, 155),
    ("P008", "Milk 1L", "Dairy", 30, 48, 58),
    ("P009", "Butter 500g", "Dairy", 25, 180, 220),
    ("P010", "Cheese 200g", "Dairy", 20, 90, 115),
    ("P011", "Biscuits", "Snacks", 120, 10, 15),
    ("P012", "Chips", "Snacks", 90, 15, 20),
    ("P013", "Chocolate", "Snacks", 65, 25, 35),
    ("P014", "Instant Noodles", "Snacks", 100, 12, 18),
    ("P015", "Soft Drinks", "Beverages", 75, 30, 40),
    ("P016", "Mineral Water", "Beverages", 110, 12, 20),
    ("P017", "Shampoo", "Personal Care", 35, 110, 145),
    ("P018", "Soap", "Personal Care", 80, 28, 38),
    ("P019", "Toothpaste", "Personal Care", 45, 65, 85),
    ("P020", "Hair Oil", "Personal Care", 30, 90, 120),
    ("P021", "Detergent", "Household", 50, 95, 125),
    ("P022", "Dishwash Liquid", "Household", 40, 65, 85),
    ("P023", "Floor Cleaner", "Household", 35, 100, 130),
    ("P024", "Tissue Paper", "Household", 55, 35, 48),
    ("P025", "Notebook", "Stationery", 60, 25, 35),
    ("P026", "Pen", "Stationery", 100, 5, 10),
    ("P027", "Pencil", "Stationery", 90, 4, 8),
    ("P028", "Markers", "Stationery", 30, 25, 35),
    ("P029", "LED Bulb", "Electronics", 25, 80, 110),
    ("P030", "Battery Pack", "Electronics", 40, 35, 50)
]

products_df = pd.DataFrame(
    products,
    columns=[
        "product_id", "product_name", "category",
        "stock_quantity", "cost_price", "selling_price"
    ]
)

products_df["reorder_level"] = np.random.randint(
    15, 35, size=len(products_df)
)

products_df["supplier"] = np.random.choice(
    ["Supplier A", "Supplier B", "Supplier C"],
    size=len(products_df)
)

products_df["lead_time_days"] = np.random.randint(
    2, 8, size=len(products_df)
)

products_df["stock_value"] = (
    products_df["stock_quantity"] * products_df["cost_price"]
)

print("PRODUCT DATABASE CREATED")
display(products_df.head(10))

print("Total products:", len(products_df))

sales_records = []

end_date = pd.Timestamp.today().normalize()
start_date = end_date - pd.Timedelta(days=364)

dates = pd.date_range(start_date, end_date)

for _, product in products_df.iterrows():

    base_demand = np.random.uniform(2, 15)

    for date in dates:

        weekday_factor = 1.25 if date.weekday() in [5, 6] else 1.0

        seasonal_factor = (
            1 + 0.20 * np.sin(2 * np.pi * date.dayofyear / 365)
        )

        random_factor = np.random.uniform(0.75, 1.25)

        demand = (
            base_demand
            * weekday_factor
            * seasonal_factor
            * random_factor
        )

        units_sold = np.random.poisson(max(demand, 0.1))

        revenue = units_sold * product["selling_price"]

        sales_records.append({
            "date": date,
            "product_id": product["product_id"],
            "product_name": product["product_name"],
            "category": product["category"],
            "units_sold": units_sold,
            "revenue": revenue
        })

sales_df = pd.DataFrame(sales_records)

print("SALES HISTORY CREATED")
display(sales_df.head(10))

print("Total sales records:", len(sales_df))
print("Historical period:", sales_df["date"].min(), "to", sales_df["date"].max())

inventory_df = products_df.copy()

inventory_df["stock_status"] = np.where(
    inventory_df["stock_quantity"] <= inventory_df["reorder_level"],
    "Low Stock",
    "Healthy"
)

inventory_df["potential_revenue"] = (
    inventory_df["stock_quantity"] *
    inventory_df["selling_price"]
)

print("INVENTORY STATUS CREATED")

display(
    inventory_df[
        [
            "product_name",
            "category",
            "stock_quantity",
            "reorder_level",
            "stock_status",
            "stock_value"
        ]
    ]
)

print("\nLow stock products:",
      (inventory_df["stock_status"] == "Low Stock").sum())

from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

forecast_features = [
    "day_of_week",
    "month",
    "day_of_year",
    "is_weekend",
    "lag_1",
    "lag_7",
    "lag_14",
    "lag_28",
    "rolling_mean_7",
    "rolling_mean_28"
]

def create_features(history, date):

    return {
        "day_of_week": date.dayofweek,
        "month": date.month,
        "day_of_year": date.dayofyear,
        "is_weekend": int(date.dayofweek >= 5),

        "lag_1": history[-1],
        "lag_7": history[-7],
        "lag_14": history[-14],
        "lag_28": history[-28],

        "rolling_mean_7": np.mean(history[-7:]),
        "rolling_mean_28": np.mean(history[-28:])
    }


product_models = {}
model_metrics = {}

for product_id, group in sales_df.groupby("product_id"):

    group = group.sort_values("date")

    history = group["units_sold"].tolist()
    dates_list = group["date"].tolist()

    X = []
    y = []
    feature_dates = []

    for i in range(28, len(history)):

        features = create_features(
            history[:i],
            dates_list[i]
        )

        X.append(features)
        y.append(history[i])
        feature_dates.append(dates_list[i])

    X = pd.DataFrame(X, columns=forecast_features)
    y = np.array(y)

    cutoff = pd.Timestamp(dates_list[-1]) - pd.Timedelta(days=29)

    train_mask = np.array(feature_dates) < cutoff
    test_mask = ~train_mask

    X_train = X.loc[train_mask]
    X_test = X.loc[test_mask]

    y_train = y[train_mask]
    y_test = y[test_mask]

    model = RandomForestRegressor(
        n_estimators=120,
        max_depth=10,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )

    model.fit(X_train, y_train)

    predictions = np.maximum(model.predict(X_test), 0)

    mae = mean_absolute_error(y_test, predictions)
    rmse = np.sqrt(mean_squared_error(y_test, predictions))

    # Retrain using all available historical data
    model.fit(X, y)

    product_models[product_id] = model

    model_metrics[product_id] = {
        "MAE": round(mae, 2),
        "RMSE": round(rmse, 2)
    }

print("ALL PRODUCT MODELS TRAINED SUCCESSFULLY!")

print("Models trained:", len(product_models))

metrics_df = pd.DataFrame(model_metrics).T
display(metrics_df.head(10))

print("Average MAE:", round(metrics_df["MAE"].mean(), 2))

def generate_forecast(days=90):

    forecast_records = []

    for product_id, group in sales_df.groupby("product_id"):

        group = group.sort_values("date")

        history = group["units_sold"].tolist()

        product_name = group["product_name"].iloc[0]
        category = group["category"].iloc[0]

        model = product_models[product_id]

        # Avoid parallel-processing overhead for small predictions
        model.n_jobs = 1

        last_date = pd.Timestamp(group["date"].max())

        for day in range(1, days + 1):

            future_date = last_date + pd.Timedelta(days=day)

            features = create_features(history, future_date)

            # Use NumPy directly instead of creating a DataFrame
            feature_array = np.array(
                [[features[col] for col in forecast_features]]
            )

            prediction = max(
                0,
                float(model.predict(feature_array)[0])
            )

            forecast_records.append({
                "date": future_date,
                "product_id": product_id,
                "product_name": product_name,
                "category": category,
                "predicted_demand": round(prediction, 2)
            })

            history.append(prediction)

    return pd.DataFrame(forecast_records)


print("Generating forecasts...")

forecast_df = generate_forecast(90)

print("90-DAY FORECAST GENERATED!")

display(forecast_df.head(15))

print("Total forecast records:", len(forecast_df))

restock_df = inventory_df.copy()

forecast_summary = (
    forecast_df.groupby("product_id")
    .agg(
        demand_7=("predicted_demand", lambda x: x.iloc[:7].sum()),
        demand_30=("predicted_demand", lambda x: x.iloc[:30].sum()),
        demand_90=("predicted_demand", "sum"),
        daily_demand=("predicted_demand", "mean"),
        demand_std=("predicted_demand", "std")
    )
    .reset_index()
)

restock_df = restock_df.merge(
    forecast_summary,
    on="product_id",
    how="left"
)

restock_df["lead_time_demand"] = (
    restock_df["daily_demand"] *
    restock_df["lead_time_days"]
)

restock_df["safety_stock"] = np.ceil(
    1.65 * restock_df["demand_std"] *
    np.sqrt(restock_df["lead_time_days"])
).astype(int)

restock_df["reorder_point"] = np.ceil(
    restock_df["lead_time_demand"] +
    restock_df["safety_stock"]
).astype(int)

restock_df["days_of_stock"] = (
    restock_df["stock_quantity"] /
    restock_df["daily_demand"].replace(0, np.nan)
)

print("RESTOCKING CALCULATIONS COMPLETED!")
display(restock_df.head(10))

# CELL 17: SMART RESTOCKING RECOMMENDATIONS

# Calculate target stock for the next 30 days plus lead time
restock_df["target_stock"] = (
    restock_df["lead_time_demand"]
    + restock_df["demand_30"]
    + restock_df["safety_stock"]
)

# Determine stock status
restock_df["restock_status"] = np.where(
    restock_df["stock_quantity"] <= restock_df["lead_time_demand"],
    "Critical",
    np.where(
        restock_df["stock_quantity"] <= restock_df["reorder_point"],
        "Reorder Now",
        "Healthy"
    )
)

# Only recommend orders when stock reaches the reorder point
restock_df["recommended_order"] = np.where(
    restock_df["restock_status"] != "Healthy",
    np.ceil(
        np.maximum(
            0,
            restock_df["target_stock"] - restock_df["stock_quantity"]
        )
    ),
    0
).astype(int)

# Calculate purchase cost
restock_df["estimated_order_cost"] = (
    restock_df["recommended_order"] *
    restock_df["cost_price"]
)

print("CORRECTED RESTOCKING RECOMMENDATIONS GENERATED!")

display(
    restock_df[
        [
            "product_name",
            "stock_quantity",
            "days_of_stock",
            "reorder_point",
            "recommended_order",
            "estimated_order_cost",
            "supplier",
            "restock_status"
        ]
    ].sort_values("days_of_stock")
)


def inventory_assistant(question):

    if not question or not question.strip():
        return "Please enter a question."

    q = question.lower()

    # Restocking products
    purchase = restock_df[
        restock_df["recommended_order"] > 0
    ]

    # Specific product search
    matched = restock_df[
        restock_df["product_name"].str.lower().apply(
            lambda x: x in q
        )
    ]

    if len(matched):
        p = matched.iloc[0]

        return f"""
### {p['product_name']}
- Current stock: {p['stock_quantity']} units
- Status: {p['restock_status']}
- Days remaining: {p['days_of_stock']:.1f}
- Recommended order: {p['recommended_order']} units
- Supplier: {p['supplier']}
- Estimated cost: ₹{p['estimated_order_cost']:,.0f}
"""

    # Supplier-specific purchase list
    if "supplier" in q or "vendor" in q:

        supplier_name = next(
            (s for s in ["Supplier A", "Supplier B", "Supplier C"]
             if s.lower() in q),
            None
        )

        if supplier_name:
            data = purchase[purchase["supplier"] == supplier_name]
        else:
            data = purchase

        if data.empty:
            return "No products require purchasing from this supplier."

        return "### Products to Purchase\n\n" + data[
            ["product_name", "recommended_order",
             "supplier", "estimated_order_cost"]
        ].to_markdown(index=False)

    # Critical products
    if any(x in q for x in ["critical", "urgent"]):
        data = restock_df[
            restock_df["restock_status"] == "Critical"
        ]

    # General restocking
    elif any(x in q for x in ["reorder", "restock", "purchase", "order", "buy"]):
        data = purchase

    # Overall inventory
    elif any(x in q for x in ["stock", "inventory", "healthy"]):
        data = restock_df

    # Sales
    elif any(x in q for x in ["sales", "revenue"]):
        return f"""
### Sales Summary
- Revenue: ₹{total_revenue:,.0f}
- Units sold: {total_units_sold:,}
- Sales records: {len(sales_df):,}
"""

    else:
        return "Try asking: Which products need restocking? Or what should I order from Supplier B?"

    return f"""
### Inventory Report

Products: {len(data)}

Total recommended units: {int(data['recommended_order'].sum()):,}

Estimated purchase cost: ₹{data['estimated_order_cost'].sum():,.0f}

### Product Details

{data[['product_name', 'stock_quantity',
       'recommended_order', 'supplier',
       'estimated_order_cost', 'restock_status']].to_markdown(index=False)}
"""



# ============================================================
# STOCKPILOT AI - FINAL INTEGRATED APPLICATION
# ============================================================

import gradio as gr
import pandas as pd
import numpy as np
import plotly.express as px

# Notebook display calls are disabled in the hosted web app.
def display(*args, **kwargs):
    return None

# -----------------------------
# 1. PREPARE DASHBOARD DATA
# -----------------------------

inventory_view = inventory_df.copy()

restock_view = restock_df.sort_values(
    "recommended_order", ascending=False
).copy()

purchase_view = restock_df[
    restock_df["recommended_order"] > 0
][
    [
        "product_name",
        "supplier",
        "recommended_order",
        "cost_price",
        "estimated_order_cost",
        "restock_status"
    ]
].copy()

supplier_summary = (
    purchase_view.groupby("supplier")
    .agg(
        products=("product_name", "count"),
        units=("recommended_order", "sum"),
        estimated_cost=("estimated_order_cost", "sum")
    )
    .reset_index()
)

sales_trend = (
    sales_df.groupby("date")["revenue"]
    .sum()
    .reset_index()
)

status_summary = (
    restock_df["restock_status"]
    .value_counts()
    .reset_index()
)
status_summary.columns = ["Status", "Products"]

total_products = len(products_df)
total_units_sold = int(sales_df["units_sold"].sum())
total_revenue = float(sales_df["revenue"].sum())
inventory_value = float(products_df["stock_value"].sum())
purchase_cost = float(restock_df["estimated_order_cost"].sum())
products_to_restock = int(
    (restock_df["recommended_order"] > 0).sum()
)

# -----------------------------
# 2. CHARTS
# -----------------------------

def make_sales_chart():
    fig = px.line(
        sales_trend,
        x="date",
        y="revenue",
        title="Daily Sales Revenue",
        labels={"date": "Date", "revenue": "Revenue (₹)"}
    )
    fig.update_layout(template="plotly_white")
    return fig


def make_status_chart():
    fig = px.pie(
        status_summary,
        names="Status",
        values="Products",
        title="Inventory Health Distribution",
        hole=0.45
    )
    return fig


def make_restock_chart():
    data = restock_df.sort_values(
        "recommended_order", ascending=True
    )
    fig = px.bar(
        data,
        x="recommended_order",
        y="product_name",
        color="restock_status",
        orientation="h",
        title="Recommended Restocking Quantities",
        labels={
            "recommended_order": "Units to Order",
            "product_name": "Product"
        }
    )
    fig.update_layout(
        template="plotly_white",
        height=650
    )
    return fig


def make_forecast_chart(product_name):
    data = forecast_df[
        forecast_df["product_name"] == product_name
    ].copy()

    fig = px.line(
        data,
        x="date",
        y="predicted_demand",
        title=f"90-Day Demand Forecast: {product_name}",
        labels={
            "date": "Date",
            "predicted_demand": "Predicted Units"
        }
    )
    fig.update_layout(template="plotly_white")
    return fig


# -----------------------------
# 3. INVENTORY ASSISTANT
# -----------------------------

def inventory_assistant(question):
    if not question or not question.strip():
        return "Please enter an inventory question."

    q = question.lower().strip()

    # Search for a product name
    matched = restock_df[
        restock_df["product_name"].str.lower().apply(
            lambda name: name in q
        )
    ]

    if len(matched) > 0:
        p = matched.iloc[0]

        return f"""
### {p['product_name']}

- **Current stock:** {int(p['stock_quantity'])} units
- **Stock status:** {p['restock_status']}
- **Estimated days remaining:** {p['days_of_stock']:.1f} days
- **Reorder point:** {int(p['reorder_point'])} units
- **Recommended order:** {int(p['recommended_order'])} units
- **Supplier:** {p['supplier']}
- **Estimated order cost:** ₹{p['estimated_order_cost']:,.0f}

This recommendation is based on the project's simulated sales
history and demand forecasting model.
"""

    if any(word in q for word in ["critical", "urgent", "danger"]):
        data = restock_df[
            restock_df["restock_status"] == "Critical"
        ]
        names = ", ".join(data["product_name"].tolist())
        return f"**{len(data)} products are Critical:**\n\n{names}"

    if any(word in q for word in ["reorder", "restock", "purchase", "order"]):
        data = restock_df[
            restock_df["recommended_order"] > 0
        ]
        return f"""
### Restocking Summary

- Products requiring restock: {len(data)}
- Total units to order: {int(data['recommended_order'].sum()):,}
- Estimated purchase cost: ₹{data['estimated_order_cost'].sum():,.0f}

The purchase order contains {len(data)} products.
"""

    if any(word in q for word in ["supplier", "vendor"]):
        return "### Supplier Purchase Summary\n\n" + supplier_summary.to_markdown(index=False)

    if any(word in q for word in ["revenue", "sales", "sold"]):
        return f"""
### Sales Summary

- Total simulated revenue: ₹{total_revenue:,.0f}
- Total units sold: {total_units_sold:,}
- Sales records: {len(sales_df):,}
"""

    if any(word in q for word in ["stock", "inventory", "healthy"]):
        counts = restock_df["restock_status"].value_counts()
        return f"""
### Inventory Overview

- Total products: {total_products}
- Critical: {counts.get('Critical', 0)}
- Reorder Now: {counts.get('Reorder Now', 0)}
- Healthy: {counts.get('Healthy', 0)}
- Inventory value: ₹{inventory_value:,.0f}
"""

    return """
I can help you with:

- Current stock of a specific product
- Which products are Critical
- Restocking recommendations
- Supplier purchase summaries
- Sales and revenue
- Overall inventory health

Try asking: "What is the stock status of Rice 5kg?"
"""


# -----------------------------
# 4. BUILD GRADIO APPLICATION
# -----------------------------

with gr.Blocks(
    theme=gr.themes.Soft(),
    title="StockPilot AI"
) as demo_final:

    gr.Markdown("""
    # 📦 StockPilot AI
    ### Smart Inventory Management & Demand Forecasting

    Monitor inventory, forecast demand and make smarter
    purchasing decisions.
    """)

    with gr.Tab("Overview"):

        gr.Markdown("## Business Overview")

        with gr.Row():
            gr.Markdown(f"### Products\n# {total_products}")
            gr.Markdown(f"### Units Sold\n# {total_units_sold:,}")
            gr.Markdown(f"### Revenue\n# ₹{total_revenue:,.0f}")

        with gr.Row():
            gr.Markdown(f"### Inventory Value\n# ₹{inventory_value:,.0f}")
            gr.Markdown(f"### Products to Restock\n# {products_to_restock}")
            gr.Markdown(f"### Purchase Estimate\n# ₹{purchase_cost:,.0f}")

        with gr.Row():
            gr.Plot(value=make_sales_chart())
            gr.Plot(value=make_status_chart())

        gr.Markdown(
            "*All figures are based on simulated retail data.*"
        )

    with gr.Tab("Inventory"):

        gr.Markdown("## Product Inventory")

        gr.Dataframe(
            value=inventory_view,
            interactive=False,
            label="Current Inventory"
        )

        gr.Markdown("## Inventory Risk Analysis")
        gr.Plot(value=make_restock_chart())

    with gr.Tab("Demand Forecast"):

        gr.Markdown("## 90-Day Demand Forecast")

        forecast_product = gr.Dropdown(
            choices=sorted(forecast_df["product_name"].unique()),
            value=sorted(forecast_df["product_name"].unique())[0],
            label="Select Product"
        )

        forecast_plot = gr.Plot(
            value=make_forecast_chart(
                sorted(forecast_df["product_name"].unique())[0]
            )
        )

        forecast_product.change(
            fn=make_forecast_chart,
            inputs=forecast_product,
            outputs=forecast_plot
        )

        gr.Markdown(
            "Forecasts are generated using the Random Forest "
            "demand prediction models."
        )

    with gr.Tab("Restocking & Suppliers"):

        gr.Markdown("## Recommended Purchase Orders")

        gr.Dataframe(
            value=purchase_view,
            interactive=False,
            label="Products Requiring Restock"
        )

        gr.Markdown("## Supplier-wise Purchase Summary")

        gr.Dataframe(
            value=supplier_summary,
            interactive=False
        )

        gr.Markdown("## Restocking Quantity Analysis")
        gr.Plot(value=make_restock_chart())

        gr.Markdown(
            f"### Estimated Total Purchase Cost: ₹{purchase_cost:,.0f}"
        )

    with gr.Tab("StockPilot Assistant"):

        gr.Markdown("""
        ## Inventory Assistant

        Ask questions about your inventory, sales, products,
        suppliers and restocking recommendations.

        **Example:** What products are critical?
        """)

        user_question = gr.Textbox(
            label="Ask StockPilot",
            placeholder="e.g. What is the stock status of Rice 5kg?"
        )

        ask_button = gr.Button(
            "Ask Assistant",
            variant="primary"
        )

        assistant_response = gr.Markdown()

        ask_button.click(
            fn=inventory_assistant,
            inputs=user_question,
            outputs=assistant_response
        )

        user_question.submit(
            fn=inventory_assistant,
            inputs=user_question,
            outputs=assistant_response
        )

# -----------------------------
# 5. LAUNCH APPLICATION
# -----------------------------

print("StockPilot AI dashboard is ready.")





# Render binds the web service to the port supplied by its environment.
import os
if __name__ == "__main__":
    demo_final.launch(
        server_name="0.0.0.0",
        server_port=int(os.environ.get("PORT", 10000)),
        share=False
    )
